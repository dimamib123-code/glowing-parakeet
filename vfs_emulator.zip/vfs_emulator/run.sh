#!/bin/bash
# run.sh — скрипт запуска эмулятора

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

if [ "$1" = "--test" ]; then
    echo "Running tests..."
    cd "$SCRIPT_DIR"
    python3 tests/test_vfs.py
    python3 tests/test_parser.py
    python3 tests/test_commands.py
    python3 tests/test_config.py
    echo ""
    echo "All tests completed."
    exit 0
fi

cd "$SCRIPT_DIR"
python3 src/emulator.py "$@"
