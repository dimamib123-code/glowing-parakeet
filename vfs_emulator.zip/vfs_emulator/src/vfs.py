"""
VFS — виртуальная файловая система, хранящаяся в памяти.

Источник данных — CSV-файл. Вложенные элементы представляются
через пути с разделителем «/». Двоичные данные кодируются в base64.
"""

import csv
import base64
import hashlib


class VFSNode:
    """Узел VFS: файл или директория."""

    def __init__(self, name, is_dir=False, content="", owner="root",
                 permissions="644"):
        self.name = name
        self.is_dir = is_dir
        self.content = content
        self.owner = owner
        self.permissions = permissions
        self.children = {}

    def add_child(self, node):
        """Добавить дочерний узел."""
        self.children[node.name] = node


class VFS:
    """Виртуальная файловая система."""

    def __init__(self, vfs_name="default_vfs"):
        self.root = VFSNode("/", is_dir=True)
        self.vfs_name = vfs_name
        self.cwd = "/"  # текущая рабочая директория

    @staticmethod
    def _normalize_path(path, cwd="/"):
        """Нормализовать путь относительно текущей директории."""
        if not path:
            return cwd
        if path.startswith("/"):
            full = path
        else:
            full = cwd.rstrip("/") + "/" + path
        parts = []
        for part in full.split("/"):
            if part == "" or part == ".":
                continue
            if part == "..":
                if parts:
                    parts.pop()
                continue
            parts.append(part)
        return "/" + "/".join(parts) if parts else "/"

    def load_from_csv(self, csv_path):
        """Загрузить VFS из CSV-файла."""
        try:
            with open(csv_path, newline="", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    path = row.get("path", "").strip()
                    node_type = row.get("type", "file").strip()
                    content = row.get("content", "").strip()
                    owner = row.get("owner", "root").strip()
                    perms = row.get("permissions", "644").strip()
                    is_dir = node_type == "dir"
                    if is_dir:
                        content = ""
                    else:
                        # декодируем base64, если контент помечен как binary
                        if row.get("encoding", "").strip() == "base64":
                            try:
                                content = base64.b64decode(content).decode(
                                    "utf-8", errors="replace"
                                )
                            except Exception:
                                pass
                    self._create_path(path, is_dir, content, owner, perms)
        except FileNotFoundError:
            raise FileNotFoundError(
                f"VFS file not found: {csv_path}"
            )
        except csv.Error as exc:
            raise ValueError(f"Invalid CSV format: {exc}")

    def _create_path(self, path, is_dir, content, owner, permissions):
        """Создать узел по полному пути."""
        if not path or path == "/":
            return
        parts = [p for p in path.split("/") if p]
        current = self.root
        for i, part in enumerate(parts):
            last = i == len(parts) - 1
            if part not in current.children:
                node = VFSNode(
                    part,
                    is_dir=(is_dir if last else True),
                    content=(content if last and not is_dir else ""),
                    owner=owner,
                    permissions=permissions,
                )
                current.add_child(node)
            current = current.children[part]
        if not is_dir:
            current.content = content
            current.is_dir = False
        current.owner = owner
        current.permissions = permissions

    def resolve(self, path):
        """Найти узел по пути. Возвращает (узел, путь) или (None, путь)."""
        norm = self._normalize_path(path, self.cwd)
        if norm == "/":
            return self.root, "/"
        parts = [p for p in norm.split("/") if p]
        current = self.root
        for part in parts:
            if part not in current.children:
                return None, norm
            current = current.children[part]
        return current, norm

    def list_dir(self, path=None):
        """Вернуть список имён в директории."""
        if path is None:
            path = self.cwd
        node, _ = self.resolve(path)
        if node is None:
            return None, f"ls: cannot access '{path}': No such file or directory"
        if not node.is_dir:
            return None, f"ls: {path}: Not a directory"
        return sorted(node.children.keys()), None

    def change_dir(self, path):
        """Сменить текущую директорию."""
        node, norm = self.resolve(path)
        if node is None:
            return False, f"cd: {path}: No such file or directory"
        if not node.is_dir:
            return False, f"cd: {path}: Not a directory"
        self.cwd = norm
        return True, None

    def read_file(self, path):
        """Прочитать содержимое файла."""
        node, norm = self.resolve(path)
        if node is None:
            return None, f"cat: {path}: No such file or directory"
        if node.is_dir:
            return None, f"cat: {path}: Is a directory"
        return node.content, None

    def remove_dir(self, path):
        """Удалить директорию."""
        norm = self._normalize_path(path, self.cwd)
        if norm == "/":
            return False, "rmdir: cannot remove root directory"
        parent_path = "/".join(norm.split("/")[:-1]) or "/"
        name = norm.split("/")[-1]
        parent, _ = self.resolve(parent_path)
        if parent is None:
            return False, f"rmdir: {path}: No such file or directory"
        if name not in parent.children:
            return False, f"rmdir: {path}: No such file or directory"
        node = parent.children[name]
        if not node.is_dir:
            return False, f"rmdir: {path}: Not a directory"
        if node.children:
            return False, f"rmdir: {path}: Directory not empty"
        del parent.children[name]
        return True, None

    def touch_file(self, path):
        """Создать пустой файл, если не существует."""
        norm = self._normalize_path(path, self.cwd)
        if norm == "/":
            return False, "touch: cannot touch root"
        node, _ = self.resolve(path)
        if node is not None:
            return True, None  # файл уже существует
        parent_path = "/".join(norm.split("/")[:-1]) or "/"
        name = norm.split("/")[-1]
        parent, _ = self.resolve(parent_path)
        if parent is None or not parent.is_dir:
            return False, f"touch: cannot create '{path}': No such directory"
        parent.add_child(VFSNode(name, is_dir=False, content=""))
        return True, None

    def rmdir(self, path):
        """Alias for remove_dir."""
        return self.remove_dir(path)

    def get_vfs_hash(self):
        """Вычислить SHA-256 от строкового представления VFS."""
        lines = []

        def walk(node, prefix=""):
            for name in sorted(node.children):
                child = node.children[name]
                full = prefix + "/" + name if prefix else "/" + name
                if child.is_dir:
                    lines.append(f"dir:{full}")
                    walk(child, full)
                else:
                    lines.append(f"file:{full}:{child.content}")

        walk(self.root)
        data = "\n".join(lines).encode("utf-8")
        return hashlib.sha256(data).hexdigest()
