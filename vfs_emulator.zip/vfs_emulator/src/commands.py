"""
Команды эмулятора оболочки.

Каждая команда — функция, принимающая (args, vfs) и возвращающая
(output_lines, error_message).
"""

import calendar
import datetime


def cmd_ls(args, vfs):
    """Вывести содержимое директории."""
    target = args[0] if args else vfs.cwd
    entries, err = vfs.list_dir(target)
    if err:
        return [], err
    return entries, None


def cmd_cd(args, vfs):
    """Сменить текущую директорию."""
    if not args:
        ok, err = vfs.change_dir("/")
        return [], err
    ok, err = vfs.change_dir(args[0])
    return [], err


def cmd_exit(args, vfs):
    """Выйти из эмулятора."""
    return ["exit"], None


def cmd_cal(args, vfs):
    """Вывести календарь на текущий или указанный месяц."""
    year = None
    month = None
    if len(args) >= 2:
        try:
            month = int(args[0])
            year = int(args[1])
        except ValueError:
            return [], "cal: invalid arguments. Usage: cal [month year]"
    elif len(args) == 1:
        try:
            year = int(args[0])
            month = None
        except ValueError:
            return [], f"cal: invalid year: {args[0]}"
    else:
        now = datetime.datetime.now()
        year = now.year
        month = now.month
    if month is not None:
        if month < 1 or month > 12:
            return [], "cal: month must be 1-12"
        cal_text = calendar.month(year, month)
    else:
        cal_text = calendar.calendar(year)
    return cal_text.rstrip("\n").split("\n"), None


def cmd_cat(args, vfs):
    """Вывести содержимое файла."""
    if not args:
        return [], "cat: missing file operand"
    output = []
    for arg in args:
        content, err = vfs.read_file(arg)
        if err:
            return [], err
        if content:
            output.append(content)
    return output, None


def cmd_rmdir(args, vfs):
    """Удалить пустую директорию."""
    if not args:
        return [], "rmdir: missing operand"
    for arg in args:
        ok, err = vfs.remove_dir(arg)
        if err:
            return [], err
    return [], None


def cmd_touch(args, vfs):
    """Создать пустой файл."""
    if not args:
        return [], "touch: missing file operand"
    for arg in args:
        ok, err = vfs.touch_file(arg)
        if err:
            return [], err
    return [], None


def cmd_pwd(args, vfs):
    """Вывести текущую директорию."""
    return [vfs.cwd], None


def cmd_help(args, vfs):
    """Вывести список доступных команд."""
    help_text = [
        "Available commands:",
        "  ls [path]       - list directory contents",
        "  cd <path>       - change directory",
        "  cat <file>      - display file contents",
        "  cal [month year]- display calendar",
        "  pwd             - print working directory",
        "  rmdir <dir>     - remove empty directory",
        "  touch <file>    - create empty file",
        "  exit            - exit emulator",
    ]
    return help_text, None


COMMANDS = {
    "ls": cmd_ls,
    "cd": cmd_cd,
    "exit": cmd_exit,
    "cal": cmd_cal,
    "cat": cmd_cat,
    "rmdir": cmd_rmdir,
    "touch": cmd_touch,
    "pwd": cmd_pwd,
    "help": cmd_help,
}
