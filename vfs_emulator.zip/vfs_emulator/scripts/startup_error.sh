# Script that will stop on first error
ls
cd /nonexistent_path
ls
