#!/bin/bash
# Test: command-line parameters
echo "=== Test 1: --vfs only ==="
python3 src/emulator.py --vfs vfs_examples/vfs_minimal.csv << 'EOF'
ls
exit
EOF

echo "=== Test 2: --vfs + --script ==="
python3 src/emulator.py --vfs vfs_examples/vfs_several.csv --script scripts/startup_full.sh

echo "=== Test 3: --vfs + --config ==="
python3 src/emulator.py --vfs vfs_examples/vfs_deep.csv --config scripts/config.json << 'EOF'
ls
cd /home/user/documents
ls
exit
EOF

echo "=== Test 4: error script ==="
python3 src/emulator.py --vfs vfs_examples/vfs_several.csv --script scripts/startup_error.sh
