"""
Конфигурация эмулятора.

Параметры читаются из командной строки и JSON-конфига.
Приоритет: командная строка выше значений из файла.
"""

import json


class Config:
    """Конфигурация эмулятора оболочки."""

    def __init__(self):
        self.vfs_path = None
        self.startup_script = None
        self.config_file = None

    def load(self, cli_args):
        """Загрузить конфигурацию.

        Args:
            cli_args: dict с ключами vfs_path, startup_script, config_file.
                      Значения None означают «не указано».
        """
        # Сначала читаем конфигурационный файл, если он задан
        file_values = {}
        config_path = cli_args.get("config_file")
        if config_path:
            try:
                with open(config_path, encoding="utf-8") as f:
                    data = json.load(f)
                file_values["vfs_path"] = data.get("vfs_path")
                file_values["startup_script"] = data.get("startup_script")
            except FileNotFoundError:
                print(f"Error: config file not found: {config_path}")
            except json.JSONDecodeError as exc:
                print(f"Error: invalid config file format: {exc}")

        # Приоритет: командная строка > файл
        self.config_file = config_path
        self.vfs_path = cli_args.get("vfs_path") or file_values.get("vfs_path")
        self.startup_script = (
            cli_args.get("startup_script")
            or file_values.get("startup_script")
        )

    def dump(self):
        """Вывести все параметры в формате ключ-значение."""
        print("--- Configuration ---")
        print(f"vfs_path        = {self.vfs_path}")
        print(f"startup_script  = {self.startup_script}")
        print(f"config_file     = {self.config_file}")
        print("---------------------")

    def to_dict(self):
        """Вернуть параметры как словарь."""
        return {
            "vfs_path": self.vfs_path,
            "startup_script": self.startup_script,
            "config_file": self.config_file,
        }
