"""
Эмулятор оболочки ОС (вариант 13).

Консольный интерфейс (CLI), VFS на CSV-файлах,
конфигурация через JSON, парсер с поддержкой кавычек.
"""

import sys
import os
import argparse

from vfs import VFS
from parser import parse_input
from commands import COMMANDS
from config import Config


class Emulator:
    """Главный класс эмулятора оболочки."""

    def __init__(self, config):
        """Инициализировать эмулятор с заданной конфигурацией."""
        self.config = config
        self.vfs = VFS(vfs_name="vfs13")
        if config.vfs_path:
            try:
                self.vfs.load_from_csv(config.vfs_path)
                print(f"VFS loaded from: {config.vfs_path}")
            except (FileNotFoundError, ValueError) as exc:
                print(f"Error loading VFS: {exc}")
        else:
            print("VFS: using empty default filesystem")

    def get_prompt(self):
        """Сформировать приглашение к вводу с именем VFS."""
        return f"{self.vfs.vfs_name}:{self.vfs.cwd}$ "

    def execute(self, line):
        """Выполнить одну команду. Возвращает (output_lines, error, should_exit)."""
        try:
            cmd_name, args = parse_input(line)
        except ValueError as exc:
            return [], str(exc), False
        if cmd_name is None:
            return [], None, False
        handler = COMMANDS.get(cmd_name)
        if handler is None:
            return [], f"{cmd_name}: command not found", False
        if cmd_name == "exit":
            return ["exit"], None, True
        output, error = handler(args, self.vfs)
        return output, error, False

    def run_script(self, script_path):
        """Выполнить стартовый скрипт. Останавливается при первой ошибке."""
        try:
            with open(script_path, encoding="utf-8") as f:
                lines = f.readlines()
        except FileNotFoundError:
            print(f"Error: startup script not found: {script_path}")
            return False

        for line in lines:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            # Имитация диалога: показываем ввод
            print(f"{self.get_prompt()}{stripped}")
            output, error, should_exit = self.execute(stripped)
            if output:
                for out_line in output:
                    print(out_line)
            if error:
                print(f"Error: {error}")
                print("Script stopped due to error.")
                return False
            if should_exit:
                return True
        return True

    def run_repl(self):
        """Запустить интерактивный режим."""
        print(f"VFS Emulator — {self.vfs.vfs_name}")
        print("Type 'help' for available commands, 'exit' to quit.\n")
        while True:
            try:
                prompt = self.get_prompt()
                line = input(prompt)
            except EOFError:
                print()
                break
            if not line.strip():
                continue
            output, error, should_exit = self.execute(line)
            if output:
                for out_line in output:
                    print(out_line)
            if error:
                print(error)
            if should_exit:
                break


def parse_cli_args():
    """Разобрать аргументы командной строки."""
    parser = argparse.ArgumentParser(
        description="UNIX-like shell emulator (Variant 13)"
    )
    parser.add_argument(
        "--vfs", dest="vfs_path",
        help="Path to VFS CSV file"
    )
    parser.add_argument(
        "--script", dest="startup_script",
        help="Path to startup script"
    )
    parser.add_argument(
        "--config", dest="config_file",
        help="Path to JSON configuration file"
    )
    return parser.parse_args()


def main():
    """Точка входа."""
    cli = parse_cli_args()
    cli_dict = {
        "vfs_path": cli.vfs_path,
        "startup_script": cli.startup_script,
        "config_file": cli.config_file,
    }

    config = Config()
    config.load(cli_dict)
    config.dump()

    emu = Emulator(config)

    if config.startup_script:
        success = emu.run_script(config.startup_script)
        if not success:
            return

    emu.run_repl()


if __name__ == "__main__":
    main()
