"""
Тесты конфигурации.
"""

import os
import sys
import json
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from config import Config


def test_cli_priority():
    """Приоритет командной строки над конфиг-файлом."""
    config_data = {
        "vfs_path": "/from/config/file.csv",
        "startup_script": "/from/config/script.sh",
    }
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False
    ) as f:
        json.dump(config_data, f)
        config_path = f.name

    try:
        config = Config()
        config.load({
            "vfs_path": "/from/cli.csv",
            "startup_script": None,
            "config_file": config_path,
        })
        assert config.vfs_path == "/from/cli.csv"
        assert config.startup_script == "/from/config/script.sh"
        print("test_cli_priority: OK")
    finally:
        os.unlink(config_path)


def test_file_only():
    """Значения только из файла."""
    config_data = {
        "vfs_path": "/vfs/from/file.csv",
        "startup_script": "/script/from/file.sh",
    }
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=False
    ) as f:
        json.dump(config_data, f)
        config_path = f.name

    try:
        config = Config()
        config.load({
            "vfs_path": None,
            "startup_script": None,
            "config_file": config_path,
        })
        assert config.vfs_path == "/vfs/from/file.csv"
        assert config.startup_script == "/script/from/file.sh"
        print("test_file_only: OK")
    finally:
        os.unlink(config_path)


def test_missing_config():
    """Несуществующий конфиг-файл."""
    config = Config()
    config.load({
        "vfs_path": "/cli.csv",
        "startup_script": None,
        "config_file": "/nonexistent/config.json",
    })
    assert config.vfs_path == "/cli.csv"
    print("test_missing_config: OK")


if __name__ == "__main__":
    test_cli_priority()
    test_file_only()
    test_missing_config()
    print("\nAll config tests passed!")
