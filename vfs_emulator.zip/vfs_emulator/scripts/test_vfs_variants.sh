#!/bin/bash
# Test: different VFS configurations
echo "=== Test: minimal VFS ==="
python3 src/emulator.py --vfs vfs_examples/vfs_minimal.csv << 'EOF'
ls
cat /readme.txt
exit
EOF

echo "=== Test: several files VFS ==="
python3 src/emulator.py --vfs vfs_examples/vfs_several.csv << 'EOF'
ls
cd /home/user
ls
cat readme.txt
exit
EOF

echo "=== Test: deep hierarchy VFS ==="
python3 src/emulator.py --vfs vfs_examples/vfs_deep.csv << 'EOF'
ls
cd /home/user/documents/work
ls
cat report.txt
cd /home/user/pictures/vacation
ls
cat beach.txt
exit
EOF
