# VFS Emulator — Variant 13

Эмулятор оболочки ОС, имитирующий работу в командной строке UNIX-подобной ОС.
Реализован в виде консольного приложения (CLI) с виртуальной файловой системой (VFS)
на основе CSV-файлов.

## Возможности

- Консольный интерфейс (CLI) с приглашением, содержащим имя VFS
- Парсер командной строки с поддержкой аргументов в кавычках
- Виртуальная файловая система (VFS), загружаемая из CSV-файла
- Конфигурация через JSON-файл и параметры командной строки
- Стартовые скрипты с остановкой при первой ошибке
- Команды: `ls`, `cd`, `cat`, `cal`, `pwd`, `touch`, `rmdir`, `help`, `exit`

## Структура проекта

```
vfs_emulator/
├── src/
│   ├── emulator.py    — главный модуль, точка входа
│   ├── vfs.py         — виртуальная файловая система
│   ├── parser.py      — парсер командной строки
│   ├── commands.py    — реализация команд
│   ├── config.py      — конфигурация (CLI + JSON)
│   └── __init__.py
├── tests/
│   ├── test_vfs.py
│   ├── test_parser.py
│   ├── test_commands.py
│   └── test_config.py
├── vfs_examples/
│   ├── vfs_minimal.csv   — минимальная VFS
│   ├── vfs_several.csv   — несколько файлов и папок
│   └── vfs_deep.csv      — глубокая иерархия (3+ уровня)
├── scripts/
│   ├── startup_full.sh      — стартовый скрипт (все команды)
│   ├── startup_error.sh     — скрипт с ошибкой
│   ├── test_cli_params.sh   — тест параметров командной строки
│   ├── test_vfs_variants.sh — тест вариантов VFS
│   └── config.json          — конфигурационный файл
├── run.sh
├── Makefile
├── .gitignore
└── README.md
```

## Команды

| Команда           | Описание                                    |
|-------------------|---------------------------------------------|
| `ls [path]`       | Вывести содержимое директории                |
| `cd <path>`       | Сменить текущую директорию                   |
| `cat <file>`      | Вывести содержимое файла                     |
| `cal [month year]`| Вывести календарь (текущий месяц по умолчанию)|
| `pwd`             | Вывести текущую директорию                   |
| `touch <file>`    | Создать пустой файл                          |
| `rmdir <dir>`     | Удалить пустую директорию                    |
| `help`            | Вывести список команд                        |
| `exit`            | Выйти из эмулятора                           |

## Параметры командной строки

```
python3 src/emulator.py [--vfs PATH] [--script PATH] [--config PATH]
```

- `--vfs PATH` — путь к CSV-файлу виртуальной файловой системы
- `--script PATH` — путь к стартовому скрипту
- `--config PATH` — путь к JSON-конфигурационному файлу

### Приоритет параметров

Значения из командной строки имеют приоритет над значениями из JSON-файла.

### Формат JSON-конфигурации

```json
{
  "vfs_path": "vfs_examples/vfs_several.csv",
  "startup_script": "scripts/startup_full.sh"
}
```

## Формат VFS (CSV)

```csv
path,type,content,owner,permissions
/home,dir,,root,755
/home/user,dir,,user,755
/home/user/readme.txt,file,Hello World,user,644
```

- `path` — полный путь к элементу VFS
- `type` — `dir` для директории, `file` для файла
- `content` — текстовое содержимое файла (пустое для директорий)
- `owner` — владелец
- `permissions` — права доступа

Для двоичных данных используется колонка `encoding` со значением `base64`.

## Сборка и запуск

### Запуск эмулятора

```bash
# Интерактивный режим с VFS
python3 src/emulator.py --vfs vfs_examples/vfs_deep.csv

# Со стартовым скриптом
python3 src/emulator.py --vfs vfs_examples/vfs_deep.csv --script scripts/startup_full.sh

# С конфигурационным файлом
python3 src/emulator.py --config scripts/config.json
```

### Запуск тестов

```bash
# Все тесты
make test

# Или по отдельности
python3 tests/test_vfs.py
python3 tests/test_parser.py
python3 tests/test_commands.py
python3 tests/test_config.py
```

### Запуск через run.sh

```bash
./run.sh                    # интерактивный режим
./run.sh --test             # запустить тесты
```

## Примеры использования

```bash
# Запуск с глубокой VFS
python3 src/emulator.py --vfs vfs_examples/vfs_deep.csv

# В эмуляторе:
vfs13:/$ ls
etc  home  tmp  var
vfs13:/$ cd /home/user/documents/work
vfs13:/home/user/documents/work$ ls
report.txt
vfs13:/home/user/documents/work$ cat report.txt
Quarterly Report
vfs13:/home/user/documents/work$ cal 1 2026
    January 2026
Mo Tu We Th Fr Sa Su
          1 2 3 4
 5 6 7 8 9 10 11
12 13 14 15 16 17 18
19 20 21 22 23 24 25
26 27 28 29 30 31
vfs13:/home/user/documents/work$ cd /tmp
vfs13:/tmp$ touch test.txt
vfs13:/tmp$ ls
test.txt
vfs13:/tmp$ exit
```
