"""
Тесты команд эмулятора.
"""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from vfs import VFS
from commands import COMMANDS


def test_ls_command():
    """Команда ls."""
    vfs = VFS("test")
    vfs._create_path("/home", is_dir=True, content="",
                     owner="root", permissions="755")
    vfs._create_path("/readme.txt", is_dir=False, content="Hi",
                     owner="root", permissions="644")
    handler = COMMANDS["ls"]
    output, err = handler([], vfs)
    assert err is None
    assert "home" in output
    assert "readme.txt" in output
    print("test_ls_command: OK")


def test_cd_command():
    """Команда cd."""
    vfs = VFS("test")
    vfs._create_path("/home", is_dir=True, content="",
                     owner="root", permissions="755")
    handler = COMMANDS["cd"]
    output, err = handler(["/home"], vfs)
    assert err is None
    assert vfs.cwd == "/home"
    print("test_cd_command: OK")


def test_cat_command():
    """Команда cat."""
    vfs = VFS("test")
    vfs._create_path("/file.txt", is_dir=False, content="Hello!",
                     owner="root", permissions="644")
    handler = COMMANDS["cat"]
    output, err = handler(["/file.txt"], vfs)
    assert err is None
    assert output == ["Hello!"]
    print("test_cat_command: OK")


def test_cal_command():
    """Команда cal."""
    vfs = VFS("test")
    handler = COMMANDS["cal"]
    output, err = handler(["1", "2026"], vfs)
    assert err is None
    assert len(output) > 0
    assert "January" in output[0] or "2026" in "\n".join(output)
    print("test_cal_command: OK")


def test_touch_and_rmdir():
    """Команды touch и rmdir."""
    vfs = VFS("test")
    vfs._create_path("/tmp", is_dir=True, content="",
                     owner="root", permissions="777")
    handler = COMMANDS["touch"]
    output, err = handler(["/tmp/new.txt"], vfs)
    assert err is None
    node, _ = vfs.resolve("/tmp/new.txt")
    assert node is not None

    vfs._create_path("/tmp/empty", is_dir=True, content="",
                     owner="root", permissions="755")
    handler = COMMANDS["rmdir"]
    output, err = handler(["/tmp/empty"], vfs)
    assert err is None
    node, _ = vfs.resolve("/tmp/empty")
    assert node is None
    print("test_touch_and_rmdir: OK")


def test_unknown_command():
    """Неизвестная команда."""
    assert "nonexistent" not in COMMANDS
    print("test_unknown_command: OK")


if __name__ == "__main__":
    test_ls_command()
    test_cd_command()
    test_cat_command()
    test_cal_command()
    test_touch_and_rmdir()
    test_unknown_command()
    print("\nAll command tests passed!")
