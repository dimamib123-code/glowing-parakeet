# Start-up script for VFS emulator — all stages
# Tests: ls, cd, cat, cal, pwd, touch, rmdir, error handling

# Stage 1-4: listing and navigation
ls
pwd
cd /home
ls
pwd
cd /home/user/documents
ls
cd /

# Stage 4: cat
cat /home/user/documents/work/report.txt
cat /etc/config/app.conf
cat /var/log/system.log

# Stage 4: cal
cal
cal 1 2026
cal 2026

# Stage 5: touch
cd /tmp
touch newfile.txt
ls
cat newfile.txt

# Stage 5: rmdir
cd /home/user
rmdir empty_dir
ls
