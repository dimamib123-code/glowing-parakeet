"""
Тесты виртуальной файловой системы.
"""

import os
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from vfs import VFS


def test_create_and_resolve():
    """Создание и поиск узлов."""
    vfs = VFS("test")
    vfs._create_path("/home/user/docs", is_dir=True, content="",
                     owner="user", permissions="755")
    node, path = vfs.resolve("/home/user/docs")
    assert node is not None, "Directory should exist"
    assert node.is_dir is True, "Should be a directory"
    assert path == "/home/user/docs"
    print("test_create_and_resolve: OK")


def test_load_from_csv():
    """Загрузка VFS из CSV."""
    csv_content = "path,type,content,owner,permissions\n"
    csv_content += "/home,dir,,root,755\n"
    csv_content += "/home/user,dir,,user,755\n"
    csv_content += "/home/user/readme.txt,file,Hello World,user,644\n"

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".csv", delete=False, newline=""
    ) as f:
        f.write(csv_content)
        csv_path = f.name

    try:
        vfs = VFS("csv_test")
        vfs.load_from_csv(csv_path=csv_path)
        node, _ = vfs.resolve("/home/user/readme.txt")
        assert node is not None, "File should exist"
        assert node.content == "Hello World"
        assert node.owner == "user"
        node2, _ = vfs.resolve("/home/user")
        assert node2.is_dir is True
        print("test_load_from_csv: OK")
    finally:
        os.unlink(csv_path)


def test_change_dir():
    """Смена директории."""
    vfs = VFS("cd_test")
    vfs._create_path("/home/user", is_dir=True, content="",
                     owner="user", permissions="755")
    ok, err = vfs.change_dir("/home/user")
    assert ok is True
    assert vfs.cwd == "/home/user"
    ok, err = vfs.change_dir("..")
    assert ok is True
    assert vfs.cwd == "/home"
    ok, err = vfs.change_dir("/nonexistent")
    assert ok is False
    print("test_change_dir: OK")


def test_touch_and_rmdir():
    """Создание и удаление файлов/директорий."""
    vfs = VFS("touch_test")
    vfs._create_path("/tmp", is_dir=True, content="",
                     owner="root", permissions="777")
    ok, err = vfs.touch_file("/tmp/newfile.txt")
    assert ok is True
    node, _ = vfs.resolve("/tmp/newfile.txt")
    assert node is not None
    assert node.content == ""

    vfs._create_path("/tmp/emptydir", is_dir=True, content="",
                     owner="root", permissions="755")
    ok, err = vfs.rmdir("/tmp/emptydir")
    assert ok is True
    node, _ = vfs.resolve("/tmp/emptydir")
    assert node is None

    # rmdir на непустую директорию
    ok, err = vfs.rmdir("/tmp")
    assert ok is False
    print("test_touch_and_rmdir: OK")


def test_vfs_hash():
    """Проверка хеша VFS."""
    vfs = VFS("hash_test")
    vfs._create_path("/file.txt", is_dir=False, content="test",
                     owner="root", permissions="644")
    h1 = vfs.get_vfs_hash()
    assert isinstance(h1, str)
    assert len(h1) == 64
    print("test_vfs_hash: OK")


if __name__ == "__main__":
    test_create_and_resolve()
    test_load_from_csv()
    test_change_dir()
    test_touch_and_rmdir()
    test_vfs_hash()
    print("\nAll VFS tests passed!")
