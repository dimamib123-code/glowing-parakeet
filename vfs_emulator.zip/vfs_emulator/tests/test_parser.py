"""
Тесты парсера.
"""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from parser import parse_input


def test_simple_parse():
    """Простой разбор команды."""
    cmd, args = parse_input("ls -la /home")
    assert cmd == "ls"
    assert args == ["-la", "/home"]
    print("test_simple_parse: OK")


def test_quoted_args():
    """Разбор аргументов в кавычках."""
    cmd, args = parse_input('cat "file with spaces.txt"')
    assert cmd == "cat"
    assert args == ["file with spaces.txt"]
    print("test_quoted_args: OK")


def test_single_quotes():
    """Одинарные кавычки."""
    cmd, args = parse_input("echo 'hello world'")
    assert cmd == "echo"
    assert args == ["hello world"]
    print("test_single_quotes: OK")


def test_empty_input():
    """Пустой ввод."""
    cmd, args = parse_input("")
    assert cmd is None
    assert args == []
    print("test_empty_input: OK")


def test_no_args():
    """Команда без аргументов."""
    cmd, args = parse_input("exit")
    assert cmd == "exit"
    assert args == []
    print("test_no_args: OK")


if __name__ == "__main__":
    test_simple_parse()
    test_quoted_args()
    test_single_quotes()
    test_empty_input()
    test_no_args()
    print("\nAll parser tests passed!")
