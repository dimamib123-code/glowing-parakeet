"""
Парсер командной строки эмулятора.

Корректно обрабатывает аргументы в одинарных и двойных кавычках.
"""

import shlex


def parse_input(line):
    """Разобрать строку ввода на команду и аргументы.

    Поддерживает аргументы в кавычках (одинарных и двойных).
    Возвращает кортеж (command, args) или (None, []) при пустом вводе.
    """
    line = line.strip()
    if not line:
        return None, []
    try:
        parts = shlex.split(line)
    except ValueError as exc:
        raise ValueError(f"Parse error: {exc}")
    if not parts:
        return None, []
    return parts[0], parts[1:]
